import acm.graphics.GRect;
import com.shpp.cs.a.graphics.*;

import java.awt.event.MouseEvent;

public class MyGraphicsProgram extends WindowProgram {

    private static final int RECT_WIDTH = 100; // Ширина прямокутника
    private static final int RECT_HEIGHT = 100; // Висота прямокутника

    private GRect rect; // Прямокутник
    private double lastMouseX; // Координата X попереднього положення курсора миші
    private double lastMouseY; // Координата Y попереднього положення курсора миші

    // Метод, який виконується під час запуску програми
    public void run() {
        setSize(400, 400); // Встановлюємо розмір вікна

        double rectX = (getWidth() - RECT_WIDTH) / 2; // Визначаємо координату X прямокутника
        double rectY = (getHeight() - RECT_HEIGHT) / 2; // Визначаємо координату Y прямокутника

        rect = new GRect(rectX, rectY, RECT_WIDTH, RECT_HEIGHT); // Створюємо прямокутник
        add(rect); // Додаємо прямокутник на вікно
        addMouseListeners(); // Додаємо обробники подій миші
    }

    // Метод, який виконується при натисканні кнопки миші
    public void mousePressed(MouseEvent e) {
        lastMouseX = e.getX(); // Запам'ятовуємо координату X поточного положення курсора миші
        lastMouseY = e.getY(); // Запам'ятовуємо координату Y поточного положення курсора миші
    }

    // Метод, який виконується при перетягуванні миші
    public void mouseDragged(MouseEvent e) {
        double dx = e.getX() - lastMouseX; // Визначаємо зміну координати X
        double dy = e.getY() - lastMouseY; // Визначаємо зміну координати Y

        rect.move(dx, dy); // Переміщуємо прямокутник на відповідні зміни координат

        lastMouseX = e.getX(); // Оновлюємо координату X поточного положення курсора миші
        lastMouseY = e.getY(); // Оновлює
    }
}