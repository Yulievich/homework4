import acm.graphics.GObject;
import acm.graphics.GOval;
import acm.graphics.GRect;
import com.shpp.cs.a.graphics.WindowProgram;

import java.awt.*;
import java.awt.event.MouseEvent;

public class Breakout extends WindowProgram {
    //Width and height of application window in pixels
    public static final double APPLICATION_WIDTH = 400;
    public static final double APPLICATION_HEIGHT = 600;
    //Dimensions of the paddle
    private static final double PADDLE_WIDTH = 60;
    private static final double PADDLE_HEIGHT = 10;
    //Offset of the paddle up from the bottom
    private static final double PADDLE_Y_OFFSET = 30;
    //Number of bricks per row
    private static final double N_BRICKS_PER_ROW = 10;
    //Number of rows of bricks
    private static final double N_BRICK_ROWS = 10;
    //Separation between bricks
    private static final double BRICK_SEP = 4;
    //Height of a brick
    private static final double BRICK_HEIGHT = 8;
    //Radius of the ball in pixels
    private static final double BALL_RADIUS = 10;
    //Offset of the top brick row from the top
    private static final double BRICK_Y_OFFSET = BRICK_SEP + BRICK_HEIGHT;
    //Amount of games
    private static final double AMOUNT_OF_GAMES = 3;
    //Width right and left walls
    private static final double WALL_WIDTH = 4;
    //The amount of time between frames (20fps)
    private static final double PAUSE_TIME = 1000.0 / 20;
    //The initial horizontal velocity of the ball
    private static final double HORIZONTAL_VELOCITY = 1.0;
    //Gravitational acceleration
    private static final double GRAVITY = 0.425;
    //Elasticity
    private static final double ELASTICITY = 0.75;

    public void run() {
        setSize((int) APPLICATION_WIDTH, (int) APPLICATION_HEIGHT);
        matrix();
        rocket();
        threeWall();
        GObject o = drawOval();
        addMouseListeners();
    }

    private GObject selectedObject;
    private boolean isObjectSelected = false;

    @Override
    public void mousePressed(MouseEvent e) {
        selectedObject = getElementAt(e.getX(), e.getY());
        if (selectedObject != null) {
            isObjectSelected = true;
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        if (selectedObject != null) {
            double newX = e.getX() - selectedObject.getWidth() / 2.0;
            double newY = selectedObject.getY(); // Используем текущее значение Y, чтобы ракетка не меняла свое положение по вертикали

            // Проверяем выход за границы экрана слева
            if (newX < WALL_WIDTH) {
                newX = WALL_WIDTH;
            }
            // Проверяем выход за границы экрана справа
            if (newX > getWidth() - selectedObject.getWidth() - WALL_WIDTH) {
                newX = getWidth() - selectedObject.getWidth() - WALL_WIDTH;
            }
            selectedObject.setLocation(newX, newY);
        }
    }

    private void brick(int x, double y, double iter) {
        GRect realBrick = new GRect(x, y, getWidth() / (N_BRICKS_PER_ROW + BRICK_SEP), BRICK_HEIGHT);

        Color[] colors = {Color.RED, Color.ORANGE, Color.YELLOW, Color.GREEN, Color.CYAN, Color.PINK};
        double[] thresholds = {1, 3, 5, 7, 9};

        for (int i = 0; i < thresholds.length; i++) {
            if (iter <= thresholds[i]) {
                realBrick.setFilled(true);
                realBrick.setColor(colors[i]);
                break;
            }
        }
        add(realBrick);
    }

    //cycle
    private void matrix() {
        double startX = WALL_WIDTH + BRICK_SEP;
        double startY = getHeight() * 0.1;
        for (int i = 0; i < N_BRICK_ROWS; i++) {
            for (int j = 0; j < N_BRICKS_PER_ROW; j++) {
                if (j == 0) {
                    startX = WALL_WIDTH + BRICK_SEP / 2;
                }
                brick((int) startX, startY, i);
                startX += getWidth() / N_BRICKS_PER_ROW;
            }
            startY += BRICK_Y_OFFSET;
            startX = WALL_WIDTH + (BRICK_SEP / 2);
        }
    }

    private GOval drawOval() {
        GOval oval = new GOval
                (
                        (double) (getWidth() / 2) - BALL_RADIUS,
                        (double) getHeight() / 2,
                        BALL_RADIUS * 2,
                        BALL_RADIUS * 2
                );
        oval.setFilled(true);
        oval.setFillColor(Color.BLACK);
        oval.setColor(Color.BLACK);
        add(oval);
        return oval;
    }

    private void rocket() {
        GRect realRocket = new GRect
                (
                        (double) (getWidth() / 2) - (PADDLE_WIDTH / 2),
                        getHeight() - PADDLE_Y_OFFSET,
                        PADDLE_WIDTH,
                        PADDLE_HEIGHT
                );
        realRocket.setFilled(true);
        realRocket.setFillColor(Color.BLACK);
        realRocket.setColor(Color.BLACK);
        add(realRocket);
    }

    private void oneWall(double x, double y, double width, double height) {
        GRect wall = new GRect(x, y, width, height);
        wall.setFilled(true);
        wall.setFillColor(Color.BLACK);
        wall.setColor(Color.BLACK);
        add(wall);
    }

    private void threeWall() {
        //top
        oneWall(0, 0, getWidth(), BRICK_SEP);
        //left wall
        oneWall(0, 0, BRICK_SEP, getHeight());
        //right wall
        oneWall(getWidth() - BRICK_SEP, 0, BRICK_SEP, getHeight());
    }
    //Функція виявлення зіткнення м'яча зі стіною або кирпичами:
    
}